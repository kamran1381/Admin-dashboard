import React from 'react';

export default function NewUser() {
  return <div>NewUser</div>;
}
